# Starter verification — 7 October 2026

## Automatic USB feedback (9 October 2026)

- Added an explicit local automatic mode to the USB companion, without firmware
  or scene changes. It arms configured channels after two seconds of fresh
  neutral right-hand Quest data plus fresh ESP/PCA/D6 confirmation. Invalid or
  stale Quest data, or missing ESP replies, requests STOP. Data recovery needs
  neutral data again. Local STOP/manual commands cancel the mode; PCA/D6 faults,
  restart and the existing 60-second arm / three-second pull limits block it.
- Twenty automatic-control tests passed, covering startup with no headset,
  real/preview/lost/stale inputs, stable-neutral duration, single confirmed ARM,
  rejected ARM, stop/recovery, receipt loss, firmware masks, board diagnostics,
  cancellation, limits and skipped historical control lines. Existing USB
  command tests (6) and authenticated transport/source tests (11) passed.
- The identified managed USB companion was stopped after a confirmed disarm
  and reloaded with the updated code. Automatic mode acknowledged WAITING_DATA
  while Quest was unavailable. New ESP receipts confirmed both masks zero,
  zero motor PWM, PCA detected and closed D6. Local STOP was exercised: AUTO
  became OFF with masks/PWM still zero, then the requested waiting mode was
  restored. No vibrator pulse, servo jog or live Quest-driven output was tested.
- The public Orbit link became unverified during the final status check;
  the local relay and ESP remained responsive. Use Open/Refresh VR Link before
  the next headset trial. Witness Garden remains a separate static experience.

## Orbit connection checker (9 October 2026)

- Added **Check Orbit Foundry.cmd**, with a one-shot or `--watch` report of the
  verified game URL, Quest input freshness, configured USB/Wi-Fi transport,
  companion identity, new ESP receipts, PCA/D6 STATUS, arming and feedback
  values. Each missing connection has recovery instructions; reports are local
  and ignored by Git. The check never arms hardware, opens a serial port,
  sends UDP session probes or restarts services. Its only optional board query
  is STATUS through the running USB companion.
- Twelve diagnostic tests passed, covering stale/synthetic/lost tracking,
  rejected uploads, failed public links, PID reuse and the local runner,
  bounded receipt parsing, old-log suppression, STATUS-only control, USB/Wi-Fi
  guidance and no serial opening or recovery calls.
- Live read-only check verified the current public Orbit game and relay,
  fresh authenticated ESP replies on USB COM7, PCA detection and closed D6.
  Both output masks were zero. No fresh Quest upload was present while the
  headset was disconnected. No physical output was enabled or tested.

## Final submission — Witness Garden (9 October 2026)

- **Short demo revision:** reduced the timeline to 120 seconds (35 seconds planting, 30 drawing, 35 mandala, 20 reflection). Replaced the spoken explanation with four short instructions/questions totaling about 40 seconds. Presenter explanation stays outside the AI guide. Existing interaction logic, music level and Orbit Foundry are unchanged.
- The revised 120-second timeline and short-guide constraints pass with all 39 JavaScript tests. Desktop browser confirmed the 2:00 starting clock, shortened voice playback, chapter advancement/replay and updated prompts without console warnings/errors. [Two-minute scene](images/witness-garden-2min.jpg). Quest rehearsal remains pending.

- **Guided interaction update:** raised ambient music defaults from 30% to 70% and increased the pad/melody mix. Added four bundled English AI narration clips, sentence-timed captions in the headset, separate voice/music controls, replay and automatic music ducking. A stalled speech download cannot block the visual journey; failed clips can be retried.
- Added pinch/carry/release seed planting with growing flowers, tracked index-finger light drawing, and a stable two-open-hand mandala gesture with hand-form changes. Seeds require an observed open hand before a pinch; tracking loss cancels a carry without planting. Drawing skips implausible jumps and clears on loss. Visual pools are bounded to seven flowers, 180 trail segments and 48 petals.
- **39 JavaScript tests passed.** Tests cover seed ownership, release location, pinch jitter, tracking loss, phase changes, stable two-hand gestures, trail discontinuities, narration timing, cancellation of pending clips and retry after failed downloads, plus all prior game/hand/network tests. **Relay: 21 passed, one Windows symlink-permission skip**, including audio MIME/confinement coverage.
- Desktop browser checked planting, light drawing, mandala, hand-form change, AI guide playback/replay, timed captions and independent mute controls. No console warnings/errors were observed. [Guided garden preview](images/witness-garden-guided.jpg). Actual Quest reach, sound comfort and new gesture responsiveness remain unverified while the headset is unavailable. Hardware tests are postponed and glove outputs were stopped.
- The fixed public build at `a6a62029d04cd8a23a72ab4965a4021613491652` loaded the upgraded scene, hand assets and bundled narration in the desktop browser. AI guide playback and captions were observed there; the shortcut and refreshed ZIPs use this build.
- The entries below record earlier garden builds; their fixed URLs remain older versions.

- **Natural garden / articulated hand update:** replaced the geometric landscape with curved wooded banks, weathered decking, stones, grasses, lilies, clouds and birds. Water uses animated shading and sky colour, not a rendered mirror of the scene. Instancing reduces repeated scenery draw calls.
- Both bundled generic-hand meshes load and deform from all 25 joint positions/orientations. Browser rehearsal confirmed open/closed fingers, skin-tone selection and the identity form transition, with no console warnings/errors. Missing joint data uses the partial-joint fallback; complete loss hides the hand. Desktop poses are synthetic; actual Quest fit, comfort and frame rate remain to be checked.
- All 29 JavaScript tests passed, including loading both actual GLB assets, joint-driven deformation, anatomical preview orientation and tracking-loss handling. Relay tests: 21 passed, one Windows symlink-permission skip; hand-file MIME/confinement coverage included. [Natural scenery](images/witness-garden-natural.jpg) and [hand preview](images/witness-hands-natural.jpg).
- The fixed HTTPS build at commit `6c86d47` loaded the new scenery and both hand assets in the desktop browser, with no console warnings/errors. Final-demo shortcut and ZIPs point to this version; the older fixed URL remains an older scene.
- Dashboard now exposes Witness Garden and preserves Orbit Foundry at `/game.html`.
- Browser review: landscape renders; Start, chapter advancement, identity-form changes, light preview, restart and the in-world prompt panel work. No browser console errors were observed.
- All 27 JavaScript tests passed, including the 180-second timeline, visibility pauses, missing/invalid fingertip rejection and existing game/tracking/network regressions.
- Original game loaded through the current public HTTPS tunnel without console errors.
- Cloudflare subsequently showed intermittent 1033 errors and logged control-stream disconnects. The fixed repository-hosted Witness Garden build was then loaded successfully through rawcdn.githack.com, with the scene ready and no console errors. This static fallback has no laptop/ESP relay API.
- Scene contains no feedback-network or actuator transport. Scenery and synthesized ambient music/chimes use bundled code, with audio unlocked by a user button press.
- Team previously confirmed all five servo horns moved and all five motors vibrated in separate bench tests. Live Quest-driven glove feedback remains unverified.
- The new garden's headset layout, fingertip reach and sound require the final Quest rehearsal. Body ownership is a participant report, not an engineering test result.

The older sections below describe earlier build milestones and their then-current limitations.

## Selected WebXR revision

- **8 October — judging preparation:** the team confirmed the official Tattva as consciousness beyond body and mind, with agency/identity/ownership as suggested approaches, and confirmed physical output is still unverified. Added a rubric plan, modular four-person speaking script, verified Gita 13.2 / 2.14 with paraphrased meanings, blank informal observation sheet and offline spectator cards. No presentation duration is imposed. The cards distinguish actual representation, participant report and philosophical reflection; they send no hardware commands and infer no consciousness or ownership score. The companion explanation's focus controls and narrow/wide layouts passed browser checks; the offline cards were rendered and inspected. The existing VR scene, server and board code/settings were not changed by this preparation.

- **8 October — full five-finger hardware preparation:** added `nodemcu_wifi_glove` and local `wifi-glove` sender for all five existing Quest vibration/resistance requests. The running scene, WebXR source/server, previous receive-only firmware and one-index firmware were not changed. A single PCA9685 uses servo channels 0–4 and NPN base-control channels 8–12; all share approximately 50 Hz. The old index D5 output stays LOW. Each motor needs its own driver, diode and suitable 3 V rail; servos need a separate suitable 5 V V+ rail.
- Both ESP8266 / Arduino core 3.1.2 builds passed: shipped disabled defaults use 30,276 bytes RAM / 290,351 bytes flash; a separate off-board all-five configuration with public dummy credentials/key and mixed servo directions uses 30,280 bytes RAM / 290,379 bytes flash. Neither was uploaded. Private Wi-Fi/pairing files were not packaged.
- Fifty-one Python tests completed: 50 passed, one Windows symlink-permission skip. Six new tests cover independent ordered channels, tampering every payload byte, tracking/release/source-age/fetch-delay zeroing, actual mock UDP authenticated receipts, invalid masks/pulses, wrong keys, reboot handling, expiry and out-of-order ACKs. All native protocol, monitor, index bench, five-finger controller/output-planner and C# interoperability checks passed. Five-finger native checks exercise selected-only outputs, disabled startup, per-servo limits/directions/ramp, stop/lease/pull/arm expiry, sequence/clock wrap and 300 ms parking without restart. Actual PCA electrical signals and physical release are not measured by these tests.
- The standalone [five-finger ZIP](../artifacts/AHAM-Five-Finger-Hardware.zip) passed archive integrity, no-secret/no-binary inclusion checks, disabled defaults, repeatable pairing setup, CLI import/help and all 12 packaged Python checks. The [full wiring guide](five-finger-hardware.md) specifies per-driver connections, source separation, signal-only motor channels, per-finger calibration and local arming. Motor startup/base-drive sufficiency, shared-50 Hz vibration response, actuator current, tension, power and mechanical release remain unverified. All shipped verification masks are zero; no hardware was flashed or actuated.

- **8 October — one-index hardware preparation:** added separate `nodemcu_wifi_bench` firmware and local `wifi-bench` companion. Website files, current server/tunnel, old receive-only firmware and legacy sensor firmware were not changed. Only the second/index vibration and resistance channels are selected. Defaults disable both actuator circuits; serial local arming, a removable D6 stop loop, boot/session replay rejection, HMAC pairing, 250 ms leases, 60 s arm expiry, 3 s pull expiry and small bounded servo pulses are implemented.
- ESP8266 / Arduino core 3.1.2 builds succeeded for shipped disabled defaults (29,772 bytes RAM / 284,215 bytes flash) and a separate off-board build with public dummy credentials and both output code paths enabled (29,784 bytes RAM / 285,579 bytes flash). Neither image was uploaded. The enabled build used only public test settings, not actual Wi-Fi credentials.
- Forty-five Python tests completed: 44 passed, one Windows symlink-permission skip. Eight new bench checks cover index selection, signature/header/body tampering, tracking/release/age/fetch-delay zeros, actual mock UDP handshake/receipt matching, bad keys, reboot nonce changes, receipt expiry and out-of-order ACK suppression. Native C++ checks passed against the actual controller header and a Python-encoded fixture: disabled startup, local arm conditions, release, stop, packet loss, continuous pull/session duration limits, session changes, invalid ranges, sequence/clock wrap. Native controller tests assume authentication already passed; BearSSL integration was compiled, not executed on hardware.
- [Hardware quickstart](index-hardware-quickstart.md) and [one-index ZIP](../artifacts/AHAM-Index-Hardware.zip) document separate PCA VCC/V+ rails, 5 V servo power, a suitable separate 3 V motor supply, transistor/diode wiring, detached servo jogs and required mechanical release. The team still lacks the motor diode, and separate actuator power has not been confirmed. No physical vibration, servo motion, force, release behavior or latency has been verified; outputs remain disabled pending these checks.

- **8 October — Orbit Foundry v4:** the team confirmed actual ESP Wi-Fi receipts, including changing VIB, RES%, HOLD and OUTPUT=OFF. Browser refinement keeps that observation protocol and firmware unchanged.
- Twenty-two JavaScript tests pass. New checks cover fingertip-midpoint pinch attachment, stable gesture arming, candidate changes, relaxed-grip hysteresis, low-lag object/request smoothing, immediate zeros for opening/loss/invalid inputs, and consistent grab/release/delivery at 20/30/72/90/120 Hz. Shape-aware contact excludes rounded-core box corners, follows the cube's rotation and retains only existing contacts within a 3 mm exit margin.
- The immersive panel now shows a large score/timer, right-hand status and one next action. Core hover, lift ticks, landing projection, matching-dock OPEN HERE, delivery confirmation and restart progress provide spatial guidance. Raw tracked joints remain unchanged; no pose locking or synthetic replacement during tracking loss.
- Desktop DOM readouts no longer run during immersive VR; desktop updates are limited to 10 Hz and the visible panel to 8 Hz. Scratch vectors/matrices reduce repeated hand-drawing allocations. This is an implementation improvement, not a measured Quest frame-rate or end-to-end latency claim.
- Public browser rehearsal confirmed heavy-core grab, lift, matching-dock release, 200-point delivery and cleared resistance; browser error logs were empty. [v4 immersive-panel desktop preview](images/webxr-v4.jpg). Actual v4 headset comfort, hand occlusion, grab feel and network timing still require a team play-through.
- The old temporary tunnel had stopped/expired. The approved tunnel and laptop relay were restored with a new HTTPS origin; the public v4 page loaded. The Wi-Fi sender must stay running for board data delivery. No motor/servo driver was enabled or board firmware flashed during this UI revision.

- **8 October — Wi-Fi data checkpoint:** `nodemcu_wifi_monitor` compiled for NodeMCU / ESP8266 Arduino core 3.1.2 (28,708 bytes RAM, 274,207 bytes flash). This is receive-and-print firmware with the index motor pin LOW, PCA9685 OE HIGH and no actuator driver/arming commands. No firmware was flashed during preparation.
- Thirty-seven Python tests completed: 36 passed, one Windows symlink-permission skip. Added Wi-Fi channel bounds, synthetic/stale/lost/released data suppression, private target validation, real loopback UDP receipt matching, bad receipt/output flag rejection, receipt expiry and sequence wrap. The relay's new accepted-data endpoint was tested separately from unconfirmed monitor receipts and expires cue/grip snapshots independently.
- Native C++ checks decoded a fixture from the actual Python encoder into the actual firmware header, then exercised duplicates, invalid fields, sequence wrap, timeout zeroing and a new sender session after expiry. Receipt output fields remain zero. The live laptop service's `/api/wifi-preview` endpoint returned monitor-only data after refresh.
- The team selected a 2.4 GHz phone hotspot. Actual ESP receipt was subsequently confirmed in the v4 checkpoint above; packet timing remains unmeasured. Local hotspot credentials belong only in ignored `WifiSecrets.h`; no credentials or compiled binary are included in the Wi-Fi ZIP. See [the Wi-Fi guide](wifi-quickstart.md).

- Orbit Foundry v3: the team now confirms whole-hand Quest tracking and cue values. Added right-hand grasp/pinch, palm-relative carry/rotation, matching-dock delivery, 75-second scoring, combos and a reachable in-world restart. New gameplay still needs a headset play-through; desktop rehearsal demonstrated a heavy-core grab, increased requests during lift, release to zero and a 200-point dock delivery. [Desktop game proof](images/webxr-foundry.jpg)
- Thirteen JavaScript tests pass: existing five tracking/contact tests plus eight game tests covering proximity/open gating, pinch hysteresis, rigid object carry, lift/matching-dock scoring once, combos, weight-dependent bounded requests, preview suppression, loss/reacquisition, frame gaps, round end, bounded throws and missing/degenerate joints.
- Thirty Python tests pass except one Windows symlink-permission skip (29 passed). The three new grip-preview checks prove expiring five-channel storage, strict validation, origin enforcement, release/preview/loss zeroing and **no UDP or actuator packet output** from the resistance endpoint.
- Desktop rehearsal now submits no requests, avoiding competition with the live Quest; server-side synthetic suppression remains. The existing temporary HTTPS link was retained and the monitor service refreshed. Board telemetry continued to report disarmed state, motor mask 0 and zero vibration. No firmware was flashed and no actuator output enabled.
- Servo-request percentages and captured optical curls are previews, not measured tension or calibrated servo positions. Physical servo feedback remains pending the mechanism, release, power and actuator-only firmware described in [the resistance plan](servo-resistance-plan.md).

- Full-hand v2: five JavaScript tests passed, including independent cues for all five fingertips, per-finger loss, both 25-joint XR input sets, wrist translation, and preview suppression. The browser preview demonstrated five Smooth cues simultaneously, middle-finger-only contact and the left feedback hand. Both meshes and all five controls render. The team's live Quest session worked for the index starter; full-hand v2 still needs its headset reload/check. [Desktop proof](images/webxr-full-hand.jpg)

- Three.js r180 is vendored with its MIT license. The desktop browser preview produced Smooth 100/pattern 1, Rough 150/pattern 2 and Soft 80/pattern 3 contact cues; preview sends only zero monitor output. Returning to open clears contact.
- Three JavaScript tests passed for angle-based curl, fingertip contact/tracking loss, and synthetic-output suppression.
- Seventeen relay tests passed except one skipped Windows symlink test: sixteen passed. Checks include exact submitted-packet echo matching, bounded receipt history, expiry, malformed requests/frames, static-file confinement and exact external HTTPS origin validation. Existing Python checks also passed.
- Tracking loss queues a zero cue after an in-flight request; client receipts expire by age, and ending VR restores the desktop camera. These paths received code review; actual headset session transitions remain to be exercised.
- The approved temporary Cloudflare tunnel connected using HTTP2/IPv4. The headset must still demonstrate real hand poses, in-world panel visibility, contact placement, fitted-glove tracking and delay.
- The public HTTPS page loaded in the laptop browser and its API accepted requests with the configured external origin. A matching preview-zero monitor echo and real board telemetry appeared on the page. The board reported disarmed state, motor mask 0 and zero vibration. CLI DNS lookup of the temporary URL timed out, while browser access worked. [Browser proof](images/webxr-preview.jpg)
- No new firmware was flashed or actuator output enabled. Current sensor-calibration firmware requires a new actuator-only mode before external tracking can drive hardware. Servo control remains unimplemented.

The earlier Unity and hardware checks below remain a record of the fallback path.

## Passed locally

- Refined hand/scene: Unity batch compilation and rendering passed. Physics overlap checks verified the actual index-tip collider reaches each of the three selected target colliders at half curl; the open index overlaps none. Rendered open, bent, tilted and contact poses were inspected. Runtime GUI and trigger-event interaction still require the team's Play-mode check.

- Unity cue monitor: ten Python tests passed, including monitor UDP receipt, malformed/control packet rejection and cue validation. C# cue parsing and actual Unity script compilation passed. The separate monitor echoes to Unity only and has no serial route. Live contact-triggered nonzero cue receipt still needs the team's interactive demonstration.

- PlatformIO builds for `nodemcuv2` and `nodemcu_probe`, Espressif 8266 platform 4.2.1 / Arduino core 3.1.2, using Python 3.12.
- Retained `esp32dev` build, Espressif platform 6.12.0 / Arduino core 2.0.17. All three environments generated firmware images successfully.
- Arduino IDE exports `AhamIndex.ino` and `FlexCheck.ino` were converted from sketch format, compiled and linked for NodeMCU using PlatformIO / ESP8266 Arduino core 3.1.2. Both produced firmware images. This verifies compilation, not an Arduino IDE upload or a physical sensor/motor test.
- Nine Python tests covering active/legacy channel masks, CRC/check vectors, randomized frames, partial streams, corrupt/oversized recovery, simulator lease/replay behavior, stop handling, HTTP validation and a Unity-format UDP round trip.
- 60 native C++ assertions against the **actual firmware protocol and supervisor headers**, including single-finger calibration, inactive channels, disabled driver outputs, active sensor rail faults, no-sensor arming rejection, duty clamp, stale packets, lease expiry, stop, unsupported pressure, duration cap and clock/sequence wrap.
- Standalone C# protocol compilation and interoperability with four Python-generated golden frames, active/legacy masks, telemetry field offsets and CRC corruption checks.
- Unity 6000.6.4f1 imported the standalone project and compiled both the actual runtime and editor scripts. Batch execution of `Aham.AhamSetup.Create` saved `Assets/AHAM/Scenes/AhamStarter.unity` and exited with code 0. Project settings and package lock were generated by the installed editor.
- JavaScript syntax check for the simulator interface.
- Browser interaction: open/closed calibration, explicit arming, material selection, index contact output, paused command-link timeout, fault clearing and return to disarmed state.
- Real NodeMCU USB communication on **COM7 / CH340**: 199 valid telemetry packets decoded in a two-second capture at 230400 baud. State was disarmed, fault 0, sensor mask 2, motor mask 0 and all vibration outputs zero. The USB bridge was then started for Unity; the team's screenshot confirmed **USB glove via local bridge**. This verifies communication, not correct sensor wiring/calibration.
- The bridge's optional `--stats` mode printed one-second raw min/max ranges from real telemetry while forwarding to Unity; a window ranged from 0 to 520 over 100 samples. The team later confirmed nothing was connected to NodeMCU; these were floating-input readings, not flex measurements. Physical sensor stability remains untested. Eight Python tests passed after adding the diagnostic logging.

- New MPU6050 raw acquisition compiled for NodeMCU and ESP32. Signed 13-byte IMU packets and gravity tilt calculations passed Python/C# checks.
- Unity batch rendering exercised the actual hand rig in open, bent and tilted poses and exited successfully. The proof images show different joint/root transforms. Default Play preview and manual controls are implemented; interactive GUI/contact checks remain to be done.

## Still required

Update after bench bring-up: the team reports the 22 kOhm / 33 kOhm / 10 kOhm divider is connected, real flex readings update in Unity, and the virtual index finger follows bending after calibration. The local bridge observed stable 228–232 readings while stationary. This establishes the first sensor-to-Unity milestone; physical vibration and MPU6050 remain untested.

- Play the updated scene in the interactive Unity editor; verify auto preview/manual controls, GUI layout and live simulator connection. Rendered hand poses are verified, but GUI interaction/runtime contacts are not.
- Wire the actual MPU6050 breakout and verify slow tilt, neutral centering and disconnected/stale behavior. No physical IMU samples have been tested.
- Verify Unity trigger contacts and the physical arrangement of the primitive hand/blocks in play mode.
- Verify the received NodeMCU V3's A0 divider/range and module schematics; the software now targets ESP8266 rather than assuming ESP32.
- Upload only after board/wiring checks; observe real sensor ranges, stop behavior, motor current and driver polarity.
- Complete USB disconnect, reset and reconnect tests; basic real telemetry/Unity connection is verified above.
- Obtain Meta Quest 3, implement the XR pose/validity adapter and validate tracking/mounting.
- Measure physical motor onset; software framing tests are not an actuator-latency measurement.
- Build and validate a pressure mechanism before adding any servo actuation.

No hardware was flashed or actuated during this software milestone. No physical pressure, resistance or body-ownership result is claimed.

The team confirms resistors arrive after 6 PM; a 2N2222A is available, but divider values, transistor pinout, motor startup current and the completed circuit remain unverified. The motor is reported as 10 mm / 3 V. The shipped configuration advertises one index sensor and no enabled motor output; the probe requires all actuator supplies disconnected. Five physical flex channels, GSR acquisition and robust IMU orientation fusion are not implemented on the single-ADC NodeMCU. See the revised hardware guide for the current limits.
